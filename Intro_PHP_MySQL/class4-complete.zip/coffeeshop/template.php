<?php
    include 'header.php';
?>
<p>Your content here.</p>
<?php
    include 'sidebar.php';
    include 'footer.php';  
?>